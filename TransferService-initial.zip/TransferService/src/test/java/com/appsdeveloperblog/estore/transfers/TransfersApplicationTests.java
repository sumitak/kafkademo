package com.appsdeveloperblog.estore.transfers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransfersApplicationTests {

	@Test
	void contextLoads() {
	}

}
