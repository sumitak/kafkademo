package com.appsdeveloperblog.estore.DepositService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepositServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
