package com.appsdeveloperblog.core.types;

public enum OrderStatus {
    CREATED,
    APPROVED,
    REJECTED
}
