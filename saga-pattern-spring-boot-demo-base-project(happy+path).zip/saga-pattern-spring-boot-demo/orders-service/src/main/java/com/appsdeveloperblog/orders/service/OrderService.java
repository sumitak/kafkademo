package com.appsdeveloperblog.orders.service;

import com.appsdeveloperblog.core.dto.Order;

public interface OrderService {
    Order placeOrder(Order order);
}
